package com.example.demo.business;

import com.example.demo.data.SomeDataService;

public class SomeBusinessLogic {

    private SomeDataService someDataService;

    public void setSomeDataService(SomeDataService someDataService) {
        this.someDataService = someDataService;
    }

    public int calculateSum(int[] data) {
        int sum = 0;
        for (int value : data) {
            sum += value;
        }
        return sum;
        //Functional Style
        //return Arrays.stream(data).reduce(Integer::sum).orElse(0);
    }

    public int calculateSumWithADataService() {
        int sum = 0;
        int[] data = someDataService.retrieveAllData();
        for (int value : data) {
            sum += value;
        }

        return sum;
    }

    public int calculateSubstractionWithADataService() {
       /* int[] data = someDataService.retrieveAllData();
        int result = data[0];
        for (int i = 1; i < data.length; i++) {
            result -= data[i];
        }
        return result;*/
        int sub = 0;
        int[] data = someDataService.retrieveAllData();
        for (int i = 0; i < data.length; i++) {
            if (i == 0) sub = data[i];
            else if (i > 0) sub -= data[i];
        }
        return sub;
    }
}
