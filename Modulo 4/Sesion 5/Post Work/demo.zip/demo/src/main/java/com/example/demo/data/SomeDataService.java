package com.example.demo.data;

public interface SomeDataService {
    //Regresa arreglo de enteros con valores para poder hacer test
    int[] retrieveAllData();
}
