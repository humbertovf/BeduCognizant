package com.example.demo.business;

import com.example.demo.data.SomeDataService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class SomeBusinessLogicMockTest {

    @InjectMocks
    SomeBusinessLogic business;
    @Mock
    SomeDataService data;

   /* @BeforeEach
    public void instances(){
        business = new SomeBusinessLogic();
        data = mock(SomeDataService.class);
    }*/

    @Test
    public void calculateSumUsingDataService_basic(){
        when(data.retrieveAllData()).thenReturn(new int[]{1,2,3});
        int actual = business.calculateSumWithADataService();
        assertEquals(6,actual);
    }
    @Test
    public void calculateSumUsingDataService_empty(){
        when(data.retrieveAllData()).thenReturn(new int[]{});
        int actual = business.calculateSumWithADataService();
        assertEquals(0,actual);
    }
    @Test
    public void calculateSumUsingDataService_five(){
        when(data.retrieveAllData()).thenReturn(new int[]{5});
        int actual = business.calculateSumWithADataService();
        assertEquals(5,actual);
    }
    @Test
    public void calculateSubstractionUsingDataService_basic(){
        when(data.retrieveAllData()).thenReturn(new int[]{1,2,3});
        int actual = business.calculateSubstractionWithADataService();
        assertEquals(-4,actual);
    }
    @Test
    public void calculateSubstractionUsingDataService_empty(){
        when(data.retrieveAllData()).thenReturn(new int[]{});
        int actual = business.calculateSubstractionWithADataService();
        assertEquals(0,actual);
    }
    @Test
    public void calculateSubstractionUsingDataService_oneValue(){
        when(data.retrieveAllData()).thenReturn(new int[]{5});
        int actual = business.calculateSubstractionWithADataService();
        assertEquals(5,actual);
    }
}
