package com.web;

import org.springframework.data.map.repository.config.EnableMapRepositories;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
@EnableMapRepositories
public class InterviewerService {
    private final CrudRepository <Interviewer, Long> repository;

    public InterviewerService(CrudRepository<Interviewer, Long> repository) {
        this.repository = repository;

        this.repository.saveAll(defaultItems());
    }

    public static List<Interviewer> defaultItems(){
        return Arrays.asList(
                new Interviewer(0, "ramon", "garcia", "rg@email.com", true),
                new Interviewer(1, "john", "doe", "john.doe@email.com", true),
                new Interviewer(2, "will", "smith", "slap@email.com", true)
        );
    }

    public List<Interviewer> findAll() {
        List<Interviewer> list = new ArrayList<>();
        Iterable<Interviewer> items = repository.findAll();
        items.forEach(list::add);
        return list;
    }

    public Optional<Interviewer> find(long id) {

        return repository.findById(id);
    }

    public Interviewer create(Interviewer interviewer) {
        // To ensure the item ID remains unique,
        // use the current timestamp.
        Interviewer copy = new Interviewer(interviewer.getId(), interviewer.getName(), interviewer.getLastName(), interviewer.getEmail(), interviewer.isActive());
        return repository.save(copy);
    }

    public Optional<Interviewer> update(long id, Interviewer newInterviewer) {
        // Only update an item if it can be found first.
        return repository.findById(id)
                .map(oldInterviewer -> {
                    Interviewer updated = oldInterviewer.updateWith(newInterviewer);
                    return repository.save(updated);
                });
    }

    public void delete(long id) {
        repository.deleteById(id);
    }

}
