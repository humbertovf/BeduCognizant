package com.web;

import lombok.Data;
import org.springframework.data.annotation.Id;

@Data
public class Interviewer {
    private final long id;
    private final String name, lastName, email;
    private final boolean isActive;



    //ACCESS MODIFIERS
    @Id
    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }

    public boolean isActive() {
        return isActive;
    }

    public Interviewer(long id, String name, String lastName, String email, boolean isActive) {
        this.id = id;
        this.name = name;
        this.lastName = lastName;
        this.email = email;
        this.isActive = isActive;
    }

    public Interviewer updateWith(Interviewer interviewer) {
        return new Interviewer(this.id, interviewer.name, interviewer.lastName, interviewer.email, interviewer.isActive);
    }
}
