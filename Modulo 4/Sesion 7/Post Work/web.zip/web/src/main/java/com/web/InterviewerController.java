package com.web;

import java.net.URI;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
@RequestMapping("api/menu/add-interviewer")
public class InterviewerController {
    private final InterviewerService interviewerService;

    private static final String template = "Hello, %s!";
    private final AtomicLong counter = new AtomicLong();

    public InterviewerController(InterviewerService interviewerService) {
        this.interviewerService = interviewerService;
    }

   /*@GetMapping("/add-interviewer")
    public Interviewer interviewer(@RequestParam(value = "name", defaultValue = "World") String name) {
        return new Interviewer(counter.incrementAndGet(), String.format(template, name));
        //return new Interviewer(counter.incrementAndGet(), String.format(template, name));
    }*/

    @GetMapping
    public ResponseEntity<List<Interviewer>> findAll() {
        List<Interviewer> items = interviewerService.findAll();
        return ResponseEntity.ok().body(items);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Interviewer> find(@PathVariable("id") long id) {
        Optional<Interviewer> interviewer = interviewerService.find(id);
        return ResponseEntity.of(interviewer);
    }

    @PostMapping
    public ResponseEntity<Interviewer> create(@RequestBody Interviewer interviewer) {
        Interviewer created = interviewerService.create(interviewer);
        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                .path("/{id}")
                .buildAndExpand(created.getId())
                .toUri();
        return ResponseEntity.created(location).body(created);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Interviewer> update(
            @PathVariable("id") long id,
            @RequestBody Interviewer updatedInterviewer) {

        Optional<Interviewer> updated = interviewerService.update(id, updatedInterviewer);

        return updated
                .map(value -> ResponseEntity.ok().body(value))
                .orElseGet(() -> {
                    Interviewer created = interviewerService.create(updatedInterviewer);
                    URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                            .path("/{id}")
                            .buildAndExpand(created.getId())
                            .toUri();
                    return ResponseEntity.created(location).body(created);
                });
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Interviewer> delete(@PathVariable("id") long id) {
        interviewerService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
