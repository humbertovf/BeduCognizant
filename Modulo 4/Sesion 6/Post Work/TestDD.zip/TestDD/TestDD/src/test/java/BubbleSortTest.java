import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class BubbleSortTest {

    @Test
    public void SortEmptyList_ShouldReturnEmptyList(){
        int[] arr = new int[] {};
        assertArrayEquals(new int[]{}, BubbleSort.sort(arr));
    }

    @Test
    public void oneElement(){
        int[] arr = new int[] {1};
        assertArrayEquals(new int[]{1}, BubbleSort.sort(arr));
    }

    @Test
    public void twoElements(){
        int[] arr = new int[] {1,2};
        assertArrayEquals(new int[]{1,2}, BubbleSort.sort(arr));
    }

    @Test
    public void twoElements2(){
        int[] arr = new int[] {2,1};
        assertArrayEquals(new int[]{1,2}, BubbleSort.sort(arr));
    }

    @Test
    public void twoElements3(){
        int[] arr = new int[] {2,2};
        assertArrayEquals(new int[]{2,2}, BubbleSort.sort(arr));
    }

    @Test
    public void threeElements(){
        int[] arr = new int[] {1,2,3};
        assertArrayEquals(new int[]{1,2,3}, BubbleSort.sort(arr));
    }

    @Test
    public void threeElements2(){
        int[] arr = new int[] {2,1,3};
        assertArrayEquals(new int[]{1,2,3}, BubbleSort.sort(arr));
    }

    @Test
    public void threeElements3(){
        int[] arr = new int[] {1,3,2};
        assertArrayEquals(new int[]{1,2,3}, BubbleSort.sort(arr));
    }

    @Test
    public void threeElements4(){
        int[] arr = new int[] {2,3,1};
        assertArrayEquals(new int[]{1,2,3}, BubbleSort.sort(arr));
    }

    @Test
    public void FourElements(){
        int[] arr = new int[] {4,1,3,2};
        assertArrayEquals(new int[]{1,2,3,4}, BubbleSort.sort(arr));
    }

    @Test
    public void lotOfElements(){
        int [] arr = new int[]{10, 1, 5, 40, 12, 34, 44, 12, 11, 9};
        assertArrayEquals(new int[]{1,5,9,10,11,12,12,34,40,44}, Sorter.sort(arr));
    }

}