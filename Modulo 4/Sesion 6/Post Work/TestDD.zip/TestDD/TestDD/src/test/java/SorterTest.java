import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SorterTest {

    @Test
    public void SortEmptyList_ShouldReturnEmptyList(){
        int[] arr = new int[] {};
        assertArrayEquals(new int[]{}, Sorter.sort(arr));
    }

    @Test
    public void oneElement(){
        int[] arr = new int[] {1};
        assertArrayEquals(new int[]{1}, Sorter.sort(arr));
    }

    @Test
    public void twoElements(){
        int[] arr = new int[] {1,2};
        assertArrayEquals(new int[]{1,2}, Sorter.sort(arr));
    }

    @Test
    public void twoElements2(){
        int[] arr = new int[] {2,1};
        assertArrayEquals(new int[]{1,2}, Sorter.sort(arr));
    }

    @Test
    public void twoElements3(){
        int[] arr = new int[] {2,2};
        assertArrayEquals(new int[]{2,2}, Sorter.sort(arr));
    }

    @Test
    public void threeElements(){
        int[] arr = new int[] {1,2,3};
        assertArrayEquals(new int[]{1,2,3}, Sorter.sort(arr));
    }

    @Test
    public void threeElements2(){
        int[] arr = new int[] {2,1,3};
        assertArrayEquals(new int[]{1,2,3}, Sorter.sort(arr));
    }

    @Test
    public void threeElements3(){
        int[] arr = new int[] {1,3,2};
        assertArrayEquals(new int[]{1,2,3}, Sorter.sort(arr));
    }

    @Test
    public void threeElements4(){
        int[] arr = new int[] {2,3,1};
        assertArrayEquals(new int[]{1,2,3}, Sorter.sort(arr));
    }

    @Test
    public void FourElements(){
        int[] arr = new int[] {4,1,3,2};
        assertArrayEquals(new int[]{1,2,3,4}, Sorter.sort(arr));
    }

}