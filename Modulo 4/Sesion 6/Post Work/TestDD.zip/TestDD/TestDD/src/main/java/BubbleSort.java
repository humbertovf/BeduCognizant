public class BubbleSort {

    public static int[] sort(int[] unsorted) {

        for (int i = 0; i < unsorted.length; i++) {
            for (int j = i + 1; j < unsorted.length; j++) {
                int tmp = 0;
                if (unsorted[i] > unsorted[j]) {
                    tmp = unsorted[i];
                    unsorted[i] = unsorted[j];
                    unsorted[j] = tmp;
                }
            }
        }
        return unsorted;
    }

    /*
    //Para un elemento o ninguno
    public static int[] sort(int[] unsorted) {
        return unsorted
    }
     */

    /*
    //Para dos elementos
    public static int[] sort(int[] unsorted) {
        if (unsorted.length <= 1) return unsorted;
        if (unsorted.length == 2) {
            if (unsorted[0] > unsorted[1]) return new int[]{unsorted[1], unsorted[0]};
        }
        return unsorted;
    }
     */

    /*
    //Para tres elementos
   public static int[] sort(int[] unsorted) {
    if (unsorted.length <= 1) return unsorted;
    if (unsorted.length == 2) {
        if (unsorted[0] > unsorted[1]) return new int[]{unsorted[1], unsorted[0]};
        else return unsorted;
    }
    if(unsorted.length == 3){
        if(unsorted[0] > unsorted[1])
            return new int[]{unsorted[1],unsorted[0],unsorted[2]};
        if(unsorted[1]>unsorted[2])
            return new int[]{unsorted[0],unsorted[2],unsorted[1]};
    }
    return unsorted;
    }
     */
}
